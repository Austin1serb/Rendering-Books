package com.austin.bookclub.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import com.austin.bookclub.models.Book;

@Component
public interface BookRepository extends CrudRepository<Book, Long> {

    List<Book> findAll();

    List<Book> findByDescriptionContaining(String search);

    Long countByTitleContaining(String search);

    Long deleteByTitleStartingWith(String search);

}
