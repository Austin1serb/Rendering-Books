package com.austin.bookclub.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.austin.bookclub.models.Book;
import com.austin.bookclub.services.BookService;

@Controller
public class Bookcontroller {

    @Autowired
    BookService bookService;

    @RequestMapping("/books/{bookId}")
    public String index(
            Model model,
            @PathVariable("bookId") Long bookId
    ) {
        Book book = bookService.findBook(bookId);

        ArrayList<Book> books = (ArrayList<Book>) bookService.allBooks();

        model.addAttribute("book", book);
        model.addAttribute("books", books);

        return "index.jsp";
    }

}
